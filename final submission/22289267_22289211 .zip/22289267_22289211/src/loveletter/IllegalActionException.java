package loveletter;

/**
 * A class for representing Illegal Actions in the game Love Letter
 **/
public class IllegalActionException extends Exception{

  public IllegalActionException(String msg){
    super(msg);
  }
}

