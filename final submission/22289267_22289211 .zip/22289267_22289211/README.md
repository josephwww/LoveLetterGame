Two agents are in the agents file.
One is simple reflex agent: 22289267_22289211.java
The other one is ISMCTS agent, class includes: MyState.java, Node.java, ISMCTS.java, ISMCTSAgent.java

The main class is in LoveLetter package, running games 20 times with one simple reflex agent, one ISMCTS agent, and two random agents
Run the main class in the loveletter class and the winning times of each agent except the randoms will be the output
